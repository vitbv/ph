import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QPushButton, QLineEdit, QLabel, QFileDialog, QApplication, QWidget, QMainWindow
from PyQt5.QtGui import QPixmap
from PIL import Image
import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QWidget, QMainWindow
import PIL
import PIL.Image as Image
import PIL.ImageDraw as ImageDraw
import PIL.ImageFont
from PyQt5.QtWidgets import QColorDialog
import random
class PhotoStudio(QMainWindow):

    def __init__(self):
        super().__init__()
        uic.loadUi('main.ui', self)
        self.pushButton.clicked.connect(self.upload)

    def upload(self):
        self.fname = QFileDialog.getOpenFileName(self, 'Выбрать картинку', '')[0]
        self.image = Image.open(self.fname)
        self.image.save('copy.jpg')
        max_size = (731, 461)
        self.image.thumbnail(max_size, Image.ANTIALIAS)
        self.image.save(self.fname)
        self.pixmap = QPixmap(self.fname)
        self.label.setPixmap(self.pixmap)
        self.pushButton_7.clicked.connect(self.negative)
        self.pushButton_10.clicked.connect(self.rerun)
        self.pushButton_11.clicked.connect(self.sep)
        self.pushButton_12.clicked.connect(self.shym)
        self.pushButton_13.clicked.connect(self.purple)
        self.pushButton_9.clicked.connect(self.chb)
        self.pushButton_2.clicked.connect(self.textcolor)
        self.pushButton_3.clicked.connect(self.text)
        self.pushButton_14.clicked.connect(self.save)
    
    def save(self):
        namesave = QFileDialog.getSaveFileName()[0]        
        self.image.save(namesave)
    def textcolor(self):
        color = QColorDialog.getColor()
        self.color = color.name()
        h = self.color.lstrip('#')
        self.textc = tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))

    def text(self):
        text = self.textEdit.toPlainText()
        size = self.textEdit_2.toPlainText()
        place = self.textEdit_3.toPlainText().split(', ')
        font = PIL.ImageFont.truetype("TimesNewRoman.ttf", int(size))
        img = self.image
        draw = ImageDraw.Draw(img)
        draw.text((int(place[0]), int(place[1])), text, self.textc, font=font)
        img.save(self.fname)
        self.pixmap = QPixmap(self.fname)
        self.label.setPixmap(self.pixmap)

    def chb(self):
        pixels = self.image.load()
        x, y = self.image.size

        for i in range(x):
            for j in range(y):
                a = pixels[i, j][0]
                b = pixels[i, j][1]
                c = pixels[i, j][2]
                bw = (a + b + c) // 3
                pixels[i, j] = bw, bw, bw

        self.image.save(self.fname)
        self.pixmap = QPixmap(self.fname)
        self.label.setPixmap(self.pixmap)

    def purple(self):
        pixels = self.image.load()
        x, y = self.image.size
        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = r, b, g
        self.image.save(self.fname)
        self.pixmap = QPixmap(self.fname)
        self.label.setPixmap(self.pixmap)

    def sep(self):
        pixels = self.image.load()
        x, y = self.image.size
        for i in range(x):
            for j in range(y):
                a, b, c = pixels[i, j]
                S = (a + b + c) // 3
                a = S + 30 * 2
                b = S + 30
                c = S
                if (a > 255):
                    a = 255
                if (b > 255):
                    b = 255
                if (c > 255):
                    c = 255
                pixels[i, j] = (a, b, c)
        self.image.save(self.fname)
        self.pixmap = QPixmap(self.fname)
        self.label.setPixmap(self.pixmap)

    def negative(self):
        pixels = self.image.load()
        x, y = self.image.size

        for i in range(x):
            for j in range(y):
                r, g, b = pixels[i, j]
                pixels[i, j] = 255 - r, 255 - g, 255 - b

        self.image.save(self.fname)
        self.pixmap = QPixmap(self.fname)
        self.label.setPixmap(self.pixmap)

    def rerun(self):
        self.image = Image.open('copy.jpg')
        max_size = (731, 461)
        self.image.thumbnail(max_size, Image.ANTIALIAS)
        self.image.save(self.fname)
        self.pixmap = QPixmap(self.fname)
        self.label.setPixmap(self.pixmap)
        self.show()

    def shym(self):
        pixels = self.image.load()
        x, y = self.image.size

        for i in range(x):
            for j in range(y):
                rand = random.randint(-70, 70)
                a = pixels[i, j][0] + rand
                b = pixels[i, j][1] + rand
                c = pixels[i, j][2] + rand
                if a < 0:
                    a = 0
                if b < 0:
                    b = 0
                if c < 0:
                    c = 0
                if a > 255:
                    a = 255
                if b > 255:
                    b = 255
                if c > 255:
                    c = 255
                pixels[i, j] = a, b, c
        self.image.save(self.fname)
        self.pixmap = QPixmap(self.fname)
        self.label.setPixmap(self.pixmap)


app = QApplication(sys.argv)
ex = PhotoStudio()
ex.show()
sys.exit(app.exec_())
